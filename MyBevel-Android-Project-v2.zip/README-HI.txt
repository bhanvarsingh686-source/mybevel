MYBEVEL Android starter project (v0.1)

Is project mein:
- Dark dashboard
- Health Connect se last 7 days ke HRV, heart-rate samples aur latest sleep session read karne ka basic integration
- Recovery score abhi blank hai; personal baseline aur scoring abhi implement nahi ki gayi.

Dhyan dein:
- Yeh source project hai, ready-to-install APK nahi.
- Fitbit Air ka data pehle Google Health / Health Connect mein sync hona chahiye.
- Health Connect permission milna data hone ki guarantee nahi hai.
- App Health Connect se records padhta hai; record source ko Fitbit ke roop mein verify nahi karta.
- App data ko kisi server par upload nahi karta.
- APK build workflow GitHub Actions ke liye diya gaya hai; build/test successful hona abhi verify nahi hua.

APK banane ka tarika (phone se):
1. ZIP ko GitHub repository mein upload karein.
2. Actions tab kholein.
3. 'Build MyBevel APK' workflow select karke Run workflow dabayein.
4. Run successful hone par MyBevel-debug-apk artifact download karein.
5. ZIP artifact extract karke app-debug.apk ko Android phone par install karein.
6. Install ke baad Health Connect permissions allow karein.

Build configuration: Android Gradle Plugin 8.7.3, Gradle 8.9, Java 17.
