package com.mybevel.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.*
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.temporal.ChronoUnit

private val bg = Color(0xFF101216)
private val panel = Color(0xFF1B2028)
private val mint = Color(0xFF8EE6C0)
private val muted = Color(0xFF9BA3AD)

class MainActivity : ComponentActivity() {
    private val permissions = setOf(
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(HeartRateVariabilityRmssdRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class)
    )
    private val permissionLauncher = registerForActivityResult(
        PermissionController.createRequestPermissionResultContract()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var hrv by remember { mutableStateOf("—") }
            var heart by remember { mutableStateOf("—") }
            var sleep by remember { mutableStateOf("—") }
            var status by remember { mutableStateOf("Tap refresh to connect Health Connect.") }
            var busy by remember { mutableStateOf(false) }
            val scope = rememberCoroutineScope()
            val client = remember { HealthConnectClient.getOrCreate(this) }

            fun refresh() {
                scope.launch {
                    busy = true
                    try {
                        val granted = client.permissionController.getGrantedPermissions()
                        if (!granted.containsAll(permissions)) {
                            permissionLauncher.launch(permissions)
                            status = "Allow MyBevel to read HRV, heart rate and sleep, then tap refresh again."
                        } else {
                            val end = Instant.now()
                            val range = TimeRangeFilter.between(end.minus(7, ChronoUnit.DAYS), end)
                            val hs = client.readRecords(ReadRecordsRequest(
                                recordType = HeartRateVariabilityRmssdRecord::class,
                                timeRangeFilter = range
                            )).records
                            hrv = hs.maxByOrNull { it.time }?.heartRateVariabilityMillis
                                ?.let { String.format("%.1f ms", it) } ?: "No data"

                            val hrs = client.readRecords(ReadRecordsRequest(
                                recordType = HeartRateRecord::class, timeRangeFilter = range
                            )).records.flatMap { it.samples }.map { it.beatsPerMinute }
                            heart = if (hrs.isEmpty()) "No data" else "${hrs.average().toInt()} bpm"

                            val sessions = client.readRecords(ReadRecordsRequest(
                                recordType = SleepSessionRecord::class, timeRangeFilter = range
                            )).records
                            sleep = sessions.maxByOrNull { it.endTime }?.let {
                                val m = ChronoUnit.MINUTES.between(it.startTime, it.endTime)
                                "${m / 60}h ${m % 60}m"
                            } ?: "No data"
                            status = "Health Connect records from the last 7 days. Source depends on your synced apps."
                        }
                    } catch (e: Exception) {
                        status = "Could not read data. Check Health Connect and app permissions."
                    }
                    busy = false
                }
            }

            MaterialTheme(colorScheme = darkColorScheme(
                background = bg, surface = panel, primary = mint,
                onBackground = Color.White, onSurface = Color.White
            )) {
                Column(
                    Modifier.fillMaxSize().background(bg).padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(15.dp)
                ) {
                    Text("MyBevel", fontSize = 29.sp, fontWeight = FontWeight.Bold)
                    Text("Your personal health dashboard", color = muted)
                    Column(
                        Modifier.fillMaxWidth().background(panel, RoundedCornerShape(24.dp)).padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("RECOVERY SCORE", color = muted, fontSize = 13.sp)
                        Text("—", color = mint, fontSize = 58.sp, fontWeight = FontWeight.Bold)
                        Text("Not calculated until baseline is available", color = muted)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Metric("HRV", hrv, Modifier.weight(1f))
                        Metric("Avg. heart rate", heart, Modifier.weight(1f))
                    }
                    Metric("Latest sleep session", sleep, Modifier.fillMaxWidth())
                    Button(
                        onClick = { refresh() }, enabled = !busy,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = mint, contentColor = bg)
                    ) { Text(if (busy) "Loading…" else "Connect / Refresh Health Data") }
                    Text(status, color = muted, fontSize = 12.sp)
                    Spacer(Modifier.weight(1f))
                    Text("Personal-use prototype • Not a medical device", color = muted, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun Metric(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier.background(panel, RoundedCornerShape(18.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(label, color = muted, fontSize = 13.sp)
        Text(value, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
    }
}
